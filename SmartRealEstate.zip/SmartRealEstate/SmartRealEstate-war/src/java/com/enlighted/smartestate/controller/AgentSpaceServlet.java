package com.enlighted.smartestate.controller;

import com.enlighted.smartestate.entity.Agents;
import com.enlighted.smartestate.entity.Cities;
import com.enlighted.smartestate.entity.Customers;
import com.enlighted.smartestate.entity.DealTypes;
import com.enlighted.smartestate.entity.Deals;
import com.enlighted.smartestate.entity.Realproperties;
import com.enlighted.smartestate.session.AgentsFacade;
import com.enlighted.smartestate.session.CitiesFacade;
import com.enlighted.smartestate.session.DealTypesFacade;
import com.enlighted.smartestate.session.DealsFacade;
import com.enlighted.smartestate.session.DealsManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 *
 * @author m
 */
@WebServlet(name = "AgentSpaceServlet",
        loadOnStartup = 1,
        urlPatterns = {
            "/account/agent/home",
            "/account/agent/profil",
            "/account/agent/upload",
            "/account/agent/edit_profil",
            "/account/agent/edit",
            "/account/agent/delete",
            "/account/agent/deals",
            "/account/agent/deal",
            "/account/agent/cancel",
            "/account/agent/confirm",
            "/account/agent/remove",
            "/account/agent/estate",
            "/account/agent/post",
            "/account/agent/place",
            "/account/agent/search",
            "/account/agent/logout"
        })
@MultipartConfig(location = "/images", fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5)
public class AgentSpaceServlet extends HttpServlet {

    @EJB
    private CitiesFacade citiesFacade;

    @EJB
    private DealTypesFacade dealTypesFacade;

    @EJB
    private DealsFacade dealsFacade;

    @EJB
    private DealsManager dealsManager;

    private final static Logger LOGGER
            = Logger.getLogger(AgentSpaceServlet.class.getCanonicalName());
    @EJB
    private AgentsFacade agentsFacade;

    @Override
    public void init() throws ServletException {
        super.init();

    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String urlPath = request.getServletPath();
        HttpSession session = request.getSession();
        Agents agent = agentsFacade.find(1);
        session.setAttribute("agent", agent);

        if (urlPath.equals("/account/agent/home")) {

        } else if (urlPath.equals("/account/agent/account")) {

        } else if (urlPath.equals("/account/agent/estate")) {
            Agents agents = (Agents) session.getAttribute("agent");
            Collection<Realproperties> properties = agents.getRealpropertiesCollection();
            request.setAttribute("agentProperties", properties);

        } else if (urlPath.equals("/account/agent/deals")) {
            Collection<Deals> agentDeals = new ArrayList<>();
            agent = (Agents) session.getAttribute("agent");
            Collection<Realproperties> properties = agent.getRealpropertiesCollection();
            for (Realproperties property : properties) {
                Collection<Deals> deals = property.getDealsCollection();
                agentDeals.addAll(deals);
            }

            request.setAttribute("agentDeals", agentDeals);

        } else if (urlPath.equals("/account/agent/deal")) {
            String reference = request.getParameter("reference");

            Deals deal = dealsFacade.findByDealReference(reference);
            //Deals deal = dealsFacade.find(Date.valueOf(reference));
            Customers customer = deal.getIdCUSTOMERS();
            Realproperties realproperty = deal.getIdREALPROPERTIES();
            Cities city = realproperty.getIdCITIES();

            DealTypes dealType = deal.getIdREALPROPERTIES().getIdDEALTYPES();

            request.setAttribute("agentSingleDeal", deal);
            request.setAttribute("customer", customer);
            request.setAttribute("property", realproperty);
            request.setAttribute("agent", agent);
            request.setAttribute("dealType", dealType);

        } else if (urlPath.equals("/account/agent/search")) {

        } else if (urlPath.equals("/account/agent/upload")) {
            String propertyName = request.getParameter("name");
            String address = request.getParameter("address");
            String city = request.getParameter("city");
            String propertyType = request.getParameter("propertyType");
            String numberofroom = request.getParameter("numberofRoom");
            String propStatus = request.getParameter("propStatus");
            String dealType = request.getParameter("dealType");
            String price = request.getParameter("price");
            String amenties = request.getParameter("amenties");

            String loanPlan = request.getParameter("loanPlan");

            String bedroom = request.getParameter("bedroom");
            String bathroom = request.getParameter("bathroom");
            String builtup = request.getParameter("builtup");
            String age = request.getParameter("age");
            String plotarea = request.getParameter("plotarea");
            String description = request.getParameter("description");

            agent = agentsFacade.find(1);
            session.setAttribute("agent", agent);
            String propName;
            try {
                String[] ament = request.getParameterValues("amenty");

                propName = dealsManager.createProperties(propertyName, address, city, propertyType, numberofroom, bedroom, bathroom, age, builtup, plotarea, description, propStatus, dealType, amenties, price, loanPlan, agent, request);

                if (propName != null) {
                    uploadDealPicture(city, dealType, propName, request, response);
                }

            } catch (IOException | ServletException e) {

            }

            Collection<Realproperties> agentProperties = agent.getRealpropertiesCollection();
            request.setAttribute("newHouse", "New House Added : Share Your Deal");
            request.setAttribute("agentProperties", agentProperties);
            urlPath = "/account/agent/estate";

        } else if (urlPath.equals("/account/agent/post")) {
            String prop = request.getParameter("realprop");
            dealsManager.changePropertyStatus(prop, "POSTED");
            agent = (Agents) session.getAttribute("agent");
            Collection<Realproperties> agentProperties = agent.getRealpropertiesCollection();
            request.setAttribute("agentProperties", agentProperties);

            urlPath = "/account/agent/estate";

        } else if (urlPath.equals("/account/agent/delete")) {
            String prop = request.getParameter("realprop");
            dealsManager.changePropertyStatus(prop, "CREATED");
            agent = (Agents) session.getAttribute("agent");
            Collection<Realproperties> agentProperties = agent.getRealpropertiesCollection();
            request.setAttribute("agentProperties", agentProperties);

            urlPath = "/account/agent/estate";

        } else if (urlPath.equals("/account/agent/place")) {
            String dealReference = request.getParameter("reference");
            Deals agentDeal = dealsManager.changeDealStatus(dealReference, "PENDING","ONDEAL");
            request.setAttribute("agentDeal", agentDeal);
            urlPath = "/account/agent/deal";

        } else if (urlPath.equals("/account/agent/remove")) {
            String dealReference = request.getParameter("reference");
            Deals agentDeal = dealsManager.changeDealStatus(dealReference, "REMOVE","POSTED");
            request.setAttribute("agentDeal", agentDeal);
            urlPath = "/account/agent/deal";

        } else if (urlPath.equals("/account/agent/cancel")) {
            String dealReference = request.getParameter("reference");
            Deals agentDeal = dealsManager.changeDealStatus(dealReference, "CANCEL","POSTED");
            request.setAttribute("agentDeal", agentDeal);
            urlPath = "/account/agent/deal";

        } else if (urlPath.equals("/account/agent/confirm")) {
            String dealReference = request.getParameter("reference");
            Deals agentDeal = dealsManager.changeDealStatus(dealReference, "CONFIRM","DEALED");
            request.setAttribute("agentDeal", agentDeal);
            urlPath = "/account/agent/deal";

        } else if (urlPath.equals("/account/agent/edit")) {
            dealsManager.loadPropertiesForm(request);
            urlPath = "/account/agent/edit";

        } else if (urlPath.equals("/account/agent/logout")) {
            urlPath = "/account/agent/home";
        }
        String url = urlPath + ".jsp";
        getServletContext().getRequestDispatcher(url).forward(request, response);

    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public void uploadDealPicture(String city, String deal, String fName, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // Create path components to save the file
        //String tmpPath = request.getParameter("destination");
        final String finalPath = "F:\\Business\\SmartRealEstate\\SmartRealEstate-war\\web\\images\\" + dealTypesFacade.find(Integer.valueOf(deal)).getName() + "\\" + citiesFacade.find(Integer.valueOf(city)).getName();
        System.out.println("Path: " + finalPath);
        //final Part filePart = request.getPart("file");
        Collection<Part> filePartList = request.getParts();
        //System.out.println(filePart);
        for (Part filePart : filePartList) {

            final String fileName = (String) getFileName(filePart);
            OutputStream out = null;
            InputStream filecontent = null;
            final PrintWriter writer = response.getWriter();
            try {
                out = new FileOutputStream(new File(finalPath + File.separator
                        + fileName));
                filecontent = filePart.getInputStream();
                int read = 0;
                final byte[] bytes = new byte[1024];
                while ((read = filecontent.read(bytes)) != -1) {
                    out.write(bytes, 0, read);
                }
                //writer.println("New file " + fileName + " created at " + finalPath);
                //LOGGER.log(Level.INFO, "File{0}being uploaded to {1}", new Object[]{fileName, finalPath});
            } catch (FileNotFoundException fne) {
                // writer.println("You either did not specify a file to upload or are " + "trying to upload a file to a protected or nonexistent " + "location.");
                // writer.println("<br/> ERROR: " + fne.getMessage());
                //LOGGER.log(Level.SEVERE, "Problems during file upload. Error: {0}", new Object[]{fne.getMessage()});
            } finally {
                if (out != null) {
                    out.close();
                }
                if (filecontent != null) {
                    filecontent.close();
                }
                if (writer != null) {
                    writer.close();
                }
            }
        }
        // getServletContext().getRequestDispatcher("/account/agent/estate.jsp").forward(request, response);

    }

    private String getFileName(final Part part) {
        final String partHeader = part.getHeader("content-disposition");
        LOGGER.log(Level.INFO, "Part Header = {0}", partHeader);
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }
}
