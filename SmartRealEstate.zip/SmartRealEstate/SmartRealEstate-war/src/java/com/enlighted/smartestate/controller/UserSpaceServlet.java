/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.controller;

import com.enlighted.smartestate.entity.Agents;
import com.enlighted.smartestate.entity.Cities;
import com.enlighted.smartestate.entity.Customers;
import com.enlighted.smartestate.entity.DealTypes;
import com.enlighted.smartestate.entity.Deals;
import com.enlighted.smartestate.entity.Realproperties;
import com.enlighted.smartestate.session.AgentsFacade;
import com.enlighted.smartestate.session.CustomersFacade;
import com.enlighted.smartestate.session.DealsFacade;
import com.enlighted.smartestate.session.DealsManager;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author m
 */
@WebServlet(name = "UserSpaceServlet",
        loadOnStartup = 3,
        urlPatterns = {"/account/user/home",
            "/account/user/profil",
            "/account/user/edit_profil",
            "/account/user/deals",
            "/account/user/cancel",
            "/account/user/remove",
            "/account/user/confirm",
            "/account/user/deal",
            "/account/user/logout",
            "/account/user/search"})
public class UserSpaceServlet extends HttpServlet {

    @EJB
    private CustomersFacade customersFacade;

    @EJB
    private DealsManager dealsManager;

    @EJB
    private AgentsFacade agentsFacade;

    @EJB
    private DealsFacade dealsFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String urlPath = request.getServletPath();
        String resource;
        HttpSession session = request.getSession();
        Customers customers = customersFacade.find(1);
        session.setAttribute("customer", customers);

        if (urlPath.equals("/account/user/home")) {

        } else if (urlPath.equals("/account/user/profil")) {

        } else if (urlPath.equals("/account/user/deals")) {
            List<Deals> deals = dealsFacade.findByIdCUSTOMERS(customers);
            request.setAttribute("userDealsList", deals);

        } else if (urlPath.equals("/account/user/deal")) {
            String reference = request.getParameter("reference");

            Deals deal = dealsFacade.findByDealReference(reference);
            //Deals deal = dealsFacade.find(Date.valueOf(reference));
            customers = deal.getIdCUSTOMERS();
            Realproperties realproperty = deal.getIdREALPROPERTIES();
            Cities city = realproperty.getIdCITIES();
            Agents agent = agentsFacade.find(deal.getIdAgents());
            DealTypes dealType = deal.getIdREALPROPERTIES().getIdDEALTYPES();

            request.setAttribute("userSingleDeal", deal);
            request.setAttribute("customer", customers);
            request.setAttribute("property", realproperty);
            request.setAttribute("agent", agent);
            request.setAttribute("dealType", dealType);
            request.setAttribute("city", city);
        } else if (urlPath.equals("/account/user/search")) {

        } else if (urlPath.equals("/account/user/confirm")) {
            String dealReference = request.getParameter("dealId");
            Deals deal = dealsManager.changeDealStatus(dealReference, "CONFIRM","ONDEAL");
            request.setAttribute("userSingleDeal", deal);

            urlPath = "/account/user/deal";

        } else if (urlPath.equals("/account/user/remove")) {
            String dealReference = request.getParameter("dealId");
            Deals deal = dealsManager.changeDealStatus(dealReference, "REMOVE","POSTED");
            request.setAttribute("userSingleDeal", deal);

            urlPath = "/account/user/deal";

        } else if (urlPath.equals("/account/user/cancel")) {
            String dealReference = request.getParameter("dealId");
            Deals deal = dealsManager.changeDealStatus(dealReference, "CANCEL","POSTED");
            request.setAttribute("userSingleDeal", deal);

            urlPath = "/account/user/deal";

        } else if (urlPath.equals("/account/user/logout")) {
            session.invalidate();
            getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }
        String url = urlPath + ".jsp";
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
