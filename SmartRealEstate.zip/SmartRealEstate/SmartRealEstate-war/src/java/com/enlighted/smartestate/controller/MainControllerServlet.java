/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.controller;

import com.enlighted.smartestate.entity.Agents;
import com.enlighted.smartestate.entity.Cities;
import com.enlighted.smartestate.entity.Customers;
import com.enlighted.smartestate.entity.Realproperties;
import com.enlighted.smartestate.session.AgentsFacade;
import com.enlighted.smartestate.session.CitiesFacade;
import com.enlighted.smartestate.session.CustomersFacade;
import com.enlighted.smartestate.session.DealsManager;
import com.enlighted.smartestate.session.RealpropertiesFacade;
import com.enlighted.smartestate.validator.Validator;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author m
 */
@WebServlet(name = "MainControllerServlet",
        loadOnStartup = 1,
        urlPatterns = {
            "/city",
            "/buy",
            "/rent",
            "/hostel",
            "/single",
            "/search",
            "/loan",
            "/deals",
            "/signin",
            "/message",
            "/logout",
            "/signup",
            "/deal"})
public class MainControllerServlet extends HttpServlet {

    @EJB
    private CustomersFacade customersFacade;

    @EJB
    private DealsManager dealsManager;

    @EJB
    private AgentsFacade agentsFacade;

    @EJB
    private RealpropertiesFacade realpropertiesFacade;

    @EJB
    private CitiesFacade citiesFacade;

    @Override
    public void init() throws ServletException {
        super.init();
        getServletContext().setAttribute("mostPopularDeals", realpropertiesFacade.findAll());
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String urlPath = request.getServletPath();
        HttpSession session = request.getSession();
        Customers customers = (Customers) session.getAttribute("customer");
        if (urlPath.equals("/buy")) {
            request.setAttribute("dealParam", "buy");
            List<Cities> cities = citiesFacade.findAll();
            request.setAttribute("cities", cities);

            urlPath = "/city";

        } else if (urlPath.equals("/rent")) {
            request.setAttribute("dealParam", "rent");
            List<Cities> cities = citiesFacade.findAll();
            request.setAttribute("cities", cities);

            urlPath = "/city";

        } else if (urlPath.equals("/hostel")) {
            request.setAttribute("dealParam", "hostel");
            List<Cities> cities = citiesFacade.findAll();
            request.setAttribute("cities", cities);

            urlPath = "/city";

        } else if (urlPath.equals("/city")) {
            List<Cities> cities = citiesFacade.findAll();
            request.setAttribute("cities", cities);

            String menu = (String) request.getAttribute("dealParam");
            request.setAttribute("dealParam", menu);
            urlPath = "/city";

        } else if (urlPath.equals("/loans")) {

        } else if (urlPath.equals("/deals")) {
            String menuParam = request.getParameter("deal");
            String cityParam = request.getParameter("city");
            request.setAttribute("urlPath", urlPath);
            Cities selectedCity = citiesFacade.findByName(cityParam);
            List<Realproperties> realProperties = realpropertiesFacade.findAll();
            List<Realproperties> selectedRealpropertieses = new ArrayList<>();

            for (Realproperties realProperty : realProperties) {
                if (realProperty.getIdDEALTYPES().getName().equalsIgnoreCase(menuParam)
                        && realProperty.getIdCITIES().getName().equalsIgnoreCase(cityParam)
                        && (realProperty.getStatus().equals("POSTED") )) {
                    selectedRealpropertieses.add(realProperty);
                }
            }

            request.setAttribute("city", selectedCity);
            request.setAttribute("properties", selectedRealpropertieses);
            request.setAttribute("cityParam", cityParam);
            request.setAttribute("dealParam", menuParam);
            urlPath = "/deals";

        } else if (urlPath.equals("/single")) {
            String menuParam = request.getParameter("deal");
            String cityParam = request.getParameter("city");
            String propertyParam = request.getParameter("name");

            Realproperties property = realpropertiesFacade.findByPropertyName(propertyParam);
            String agencyParam = property.getIdAGENTS().getOfficeName();

            request.setAttribute("property", property);
            request.setAttribute("cityParam", cityParam);
            request.setAttribute("dealParam", menuParam);
            request.setAttribute("agencyParam", agencyParam);

        } else if (urlPath.equals("/search")) {

        } else if (urlPath.equals("/deal")) {
            String agencyParam = request.getParameter("agencyname");
            String menuParam = request.getParameter("deal");
            String cityParam = request.getParameter("city");
            String propertyParam = request.getParameter("name");
            customers = (Customers) session.getAttribute("customer");
//            List<String> dealsParameters = new ArrayList<>();
//            dealsParameters.add(agencyParam);
//            dealsParameters.add(menuParam);
//            dealsParameters.add(cityParam);
//            dealsParameters.add(propertyParam);

            Realproperties property = realpropertiesFacade.findByPropertyName(propertyParam);
            Agents agent = agentsFacade.findByOfficeName(agencyParam);

            request.setAttribute("dealParam", menuParam);
            request.setAttribute("cityParam", cityParam);
            request.setAttribute("property", property);
            request.setAttribute("agent", agent);
//            session.setAttribute("dealsParameters", dealsParameters);

        } else if (urlPath.equals("/logout")) {
            session.invalidate();
            getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }

        getServletContext().setAttribute("mostPopularDeals", realpropertiesFacade.findAll());
        String url = "/WEB-INF" + urlPath + ".jsp";
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String urlPath = request.getServletPath();
        HttpSession session = request.getSession();
        Customers customers = (Customers) session.getAttribute("customer");
        if (urlPath.equals("/signin")) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");
//            List<String> dealsParameters = (List<String>) session.getAttribute("dealsParameters");
            try {
                customers = customersFacade.findByEmail(email);

//                for (Customers cust : customersFacade.findAll()) {
//                    if (cust.getEmail().equals(email) && cust.getPassword().equals(password)) {
//                        customers = cust;
//                        break;
//                    }
//                }
            } catch (Exception e) {
            }
            if (customers != null && (customers.getPassword().equals(password))) {

                session.setAttribute("customer", customers);
//                if (dealsParameters != null) {
//                    Realproperties property = realpropertiesFacade.findByPropertyName(dealsParameters.get(3));
//                    Agents agent = agentsFacade.findByOfficeName(dealsParameters.get(0));
//
//                    request.setAttribute("dealParam", dealsParameters.get(1));
//                    request.setAttribute("cityParam", dealsParameters.get(2));
//                    request.setAttribute("property", property);
//                    request.setAttribute("agent", agent);
//                    getServletContext().getRequestDispatcher("/WEB-INF/deal.jsp").forward(request, response);
//                    return;
//                }

                getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
                return;
            } else {
                request.setAttribute("message", "Please register identification does not match with any customer");
                getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
                return;
            }
        } else if (urlPath.equals("/signup")) {
            String firstName = request.getParameter("firstname");
            String lastName = request.getParameter("lastname");
            String password = request.getParameter("pword");
            String confirmPwd = request.getParameter("confirmPword");
            String email = request.getParameter("emailid");
            String phone = request.getParameter("phone");
            String sal = request.getParameter("salary");
            try {

                customers = customersFacade.findByEmail(email);
//                for (Customers cust : customersFacade.findAll()) {
//                    if (cust.getEmail().equals(email)) {
//                        customers = cust;
//                        break;
//                    }
//                }
            } catch (Exception e) {
            }
            if (customers != null) {
                request.setAttribute("message", "Please Customer already exists signup with other email id!");
                getServletContext().getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }
            double salary = 0.0;
            try {
                salary = Double.valueOf(sal);
            } catch (Exception e) {
                salary = 0;
            }

            boolean validation = Validator.validateRegisterForm(firstName, lastName, email, phone, salary, password, confirmPwd, request);

            // if validation error found, return user to checkout
            if (validation == true) {
                request.setAttribute("validation", validation);
                getServletContext().getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }
            if (customers == null) {
                customers = new Customers();
                customers.setFirstName(firstName);
                customers.setLastName(lastName);
                customers.setEmail(email);
                customers.setPhone(phone);
                customers.setPassword(password);
                customers.setSalary(salary);
                try {
                    customersFacade.create(customers);
                } catch (Exception e) {
                }
            }
            request.setAttribute("customer", customers);
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
            return;

        } else if (urlPath.equals("/message")) {
            String cust = request.getParameter("customerId");
            String agent = request.getParameter("agentId");
            String prop = request.getParameter("dealedPropertyId");
            String mess = request.getParameter("msg1");
            String dealReference = request.getParameter("reference");
            try {
                System.out.println("com.enlighted.smartestate.controller.MainControllerServlet.doPost(): " + cust + " " + agent + " " + prop + " " + mess);
                String reference = dealsManager.makeDeals(Integer.parseInt(cust), Integer.parseInt(agent), Integer.parseInt(prop), "NEW", mess);
                if (reference == null) {
                    request.setAttribute("msg", "failed to send message to the agent");
                } else {
                    System.out.println("ref :"+reference);
                    request.setAttribute("msg", "You will be contacted by the agent later on.\n Kindly SmartRealEstate");
                    request.setAttribute("closeup", "yeah");
                }
            } catch (Exception e) {
                System.out.println("com.enlighted.smartestate.controller.MainControllerServlet.doPost()ex: "+e.getMessage());
            }
            urlPath = "/deal";
        }

        getServletContext().setAttribute("mostPopularDeals", realpropertiesFacade.findAll());
        String url = "/WEB-INF" + urlPath + ".jsp";
        getServletContext().getRequestDispatcher(url).forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
