/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.session;

import com.enlighted.smartestate.entity.Agents;
import com.enlighted.smartestate.entity.Cities;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Stephane
 */
@Stateless
public class CitiesFacade extends AbstractFacade<Cities> {

    @PersistenceContext(unitName = "SmartRealEstatePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CitiesFacade() {
        super(Cities.class);
    }

     public Cities findByName(String name) {
        return (Cities) em.createNamedQuery("Cities.findByName").setParameter("name", name).getSingleResult();
    }
    
}
