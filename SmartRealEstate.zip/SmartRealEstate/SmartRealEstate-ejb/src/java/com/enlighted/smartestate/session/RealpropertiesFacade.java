/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.session;

import com.enlighted.smartestate.entity.Realproperties;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Stephane
 */
@Stateless
public class RealpropertiesFacade extends AbstractFacade<Realproperties> {

    @PersistenceContext(unitName = "SmartRealEstatePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RealpropertiesFacade() {
        super(Realproperties.class);
    }

    public Realproperties findByPropertyName(String propertyName) {
        return (Realproperties) em.createNamedQuery("Realproperties.findByPropertyName").setParameter("propertyName", propertyName).getSingleResult();
    }

    public List<Realproperties> findByPrice(double price) {
        return (List<Realproperties>) em.createNamedQuery("Realproperties.findByPrice").setParameter("propertyName", price).getResultList();
    }
}
