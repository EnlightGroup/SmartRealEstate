/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.session;

import com.enlighted.smartestate.entity.Customers;
import com.enlighted.smartestate.entity.Deals;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Stephane
 */
@Stateless
public class DealsFacade extends AbstractFacade<Deals> {

    @PersistenceContext(unitName = "SmartRealEstatePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DealsFacade() {
        super(Deals.class);
    }
    
     public List<Deals> findByIdCUSTOMERS(Customers customer) {
        return (List<Deals>) em.createNamedQuery("Deals.findByIdCUSTOMERS").setParameter("idCUSTOMERS", customer).getResultList();
    }
     
      public Deals findByIdDEALS(Date idDEALS) {
        return (Deals) em.createNamedQuery("Deals.findByIdDEALS").setParameter("idDEALS", idDEALS).getSingleResult();
    }

  

    public Deals findByDealReference(String reference) {
      return (Deals) em.createNamedQuery("Deals.findByDealReference").setParameter("dealReference", reference).getResultList().get(0);  
    }
}
