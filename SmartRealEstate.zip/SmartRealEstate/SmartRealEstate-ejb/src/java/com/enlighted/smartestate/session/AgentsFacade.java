/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.session;

import com.enlighted.smartestate.entity.Agents;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Stephane
 */
@Stateless
public class AgentsFacade extends AbstractFacade<Agents> {

    @PersistenceContext(unitName = "SmartRealEstatePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AgentsFacade() {
        super(Agents.class);
    }
    
     public Agents findByName(String name) {
        return (Agents) em.createNamedQuery("Agents.findByName").setParameter("name", name).getResultList().get(0);
    }
     
     public Agents findByOfficeName(String officeName) {
        return (Agents) em.createNamedQuery("Agents.findByOfficeName").setParameter("officeName", officeName).getResultList().get(0);
    }
}
