/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enlighted.smartestate.session;

import com.enlighted.smartestate.entity.Agents;
import com.enlighted.smartestate.entity.Amenties;
import com.enlighted.smartestate.entity.BankOffers;
import com.enlighted.smartestate.entity.Deals;
import com.enlighted.smartestate.entity.LoanPlan;
import com.enlighted.smartestate.entity.Realproperties;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Stephane
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DealsManager {

    @EJB
    private BankOffersFacade bankOffersFacade;

    @EJB
    private LoanPlanFacade loanPlanFacade;

    @EJB
    private DealTypesFacade dealTypesFacade;

    @EJB
    private PropertyTypesFacade propertyTypesFacade;

    @EJB
    private PropertyStatusFacade propertyStatusFacade;

    @EJB
    private NumberOfRoomsFacade numberOfRoomsFacade;

    @EJB
    private CitiesFacade citiesFacade;

    @EJB
    private AmentiesFacade amentiesFacade;

    @EJB
    private DealsFacade dealsFacade;

    @EJB
    private RealpropertiesFacade realpropertiesFacade;

   
    @EJB
    private CustomersFacade customersFacade;

    @PersistenceContext(unitName = "SmartRealEstatePU")
    private EntityManager em;

   // @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public String makeDeals(int customerId, int agentId, int propertyId, String b, String mess) {
        System.out.println("com.enlighted.smartestate.session.DealsManager.makeDeals()"+customerId+" "+agentId+" "+propertyId+" "+b+" "+mess);
        Date date = new java.util.Date();
        String dealReference = date.toString() + "" + propertyId + "" + agentId + "" + propertyId;
        Deals deals = null;
        try {
            List<Deals> dealList = dealsFacade.findAll();
            if(dealList != null){
            for (Deals deal : dealList) {

                if (deal.getIdCUSTOMERS().getIdCUSTOMERS().equals(customerId) &&
                       deal.getIdAgents().equals(agentId) &&
                        deal.getIdREALPROPERTIES().getIdREALPROPERTIES().equals(propertyId)) {
                    deals = deal;
                    break;
                }
//                if (deal.getIdAgents().equals(agentId)
//                        && deal.getCUSTOMERSidCUSTOMERS().getIdCUSTOMERS().equals(customerId)
//                        && deal.getIdREALPROPERTIES().getIdREALPROPERTIES().equals(propertyId)) {
//
//                    deals = deal;
//                    break;
//                }
            }
            }
            if (deals == null) {
                deals = new Deals();
                deals.setIdDEALS(date);
                deals.setDealReference(dealReference);
                deals.setIdCUSTOMERS(customersFacade.find(customerId));
                deals.setIdAgents(agentId);
                deals.setIdREALPROPERTIES(realpropertiesFacade.find(propertyId));
                deals.setMessage(mess);
                deals.setLastReview(new java.util.Date());
                deals.setStatus(b);
                System.out.println("com.enlighted.smartestate.session.DealsManager.makeDeals(): "+deals);
                dealsFacade.create(deals);
                //em.persist(deals);
            } else {
                deals.setLastReview(new java.util.Date());
                String message = deals.getMessage().concat("\n" + mess);
                deals.setMessage(message);
                System.out.println("com.enlighted.smartestate.session.DealsManager.makeDeals(): "+deals);
                dealsFacade.edit(deals);
                //em.merge(deals);
            }
            
        } catch (Exception e) {
            System.out.println("com.enlighted.smartestate.session.DealsManager.makeDeals() ex:"+e.getMessage());
            return null;
        }

        return deals.getDealReference();
    }

// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public void persist(Object object) {
        em.persist(object);
    }

    public String createProperties(String propertyName, String address, String city, String propertyType, String numberofroom, String bedroom, String bathroom, String age, String builtup, String plotarea, String description, String propStatus, String dealType, String amenties, String price, String loanPlan, Agents agent, HttpServletRequest request) {
        Realproperties realproperties = new Realproperties();

        realproperties.setPropertyName(propertyName);
        realproperties.setAddress(address);
        realproperties.setPrice(Double.valueOf(price));
        realproperties.setIdNUMBEROFROOMS(numberOfRoomsFacade.find(Integer.valueOf(numberofroom)));
        realproperties.setIdCITIES(citiesFacade.find(Integer.valueOf(city)));

        Amenties amenTies;

        if (amenties.equals("checked")) {
            String[] amentys = request.getParameterValues("amenty");
            System.out.println("amenty: " + amentys.length + " " + amentys[0]);
            amenTies = createAmenties(amentys);
        } else {
            amenTies = this.findDefaultAmenties();
        }

        realproperties.setIdAMENTIES(amenTies);
        realproperties.setStatus("CREATED");
        realproperties.setIdDEALTYPES(dealTypesFacade.find(Integer.valueOf(dealType)));
        realproperties.setIdPROPERTYTYPES(propertyTypesFacade.find(Integer.valueOf(propertyType)));
        realproperties.setIdPROPERTYSTATUS(propertyStatusFacade.find(Integer.valueOf(propStatus)));
        realproperties.setIdAGENTS(agent);

        LoanPlan plan;
        if (loanPlan != null) {
            plan = loanPlanFacade.find(Integer.valueOf(loanPlan));
        } else {
            plan = createLoanPlans(request);
            //plan = loanPlanFacade.findDefaultPlan();
        }

        realproperties.setIdLOANPLAN(plan);
        realproperties.setAge(Integer.valueOf(age));
        realproperties.setBathroom(Integer.valueOf(bathroom));
        realproperties.setBedroom(Integer.valueOf(bedroom));
        realproperties.setBuildupArea(Integer.valueOf(builtup));
        realproperties.setPlotArea(Integer.valueOf(plotarea));
        realproperties.setDescription(description);
        
        realpropertiesFacade.create(realproperties);

        return realproperties.getPropertyName();
    }

    public Amenties createAmenties(String[] amentys) {
        
        Amenties amenTies = new Amenties();

        for (String am : amentys) {
            switch (am) {
                case "LIFT":
                    amenTies.setLift(Boolean.TRUE);
                    break;
                case "GARAGE":
                    amenTies.setGarage(Boolean.TRUE);
                    break;
                case "GYM":
                    amenTies.setGym(Boolean.TRUE);
                    break;
                case "SWIM":
                    amenTies.setSwimmingpool(Boolean.TRUE);
                    break;
                case "GAZ":
                    amenTies.setGazpipeline(Boolean.TRUE);
                    break;
                default:

                    break;
            }
        }

    

            amentiesFacade.create(amenTies);
        
        return amenTies;
    }

    public LoanPlan createLoanPlans(HttpServletRequest request) {
        boolean isExited = false;
        boolean isBankOfferExited = false;
        LoanPlan loanPlan = new LoanPlan();
        BankOffers bankOffers = new BankOffers();

        String bankName = request.getParameter("bankname");
        String salarial = request.getParameter("salarial");
        String margin = request.getParameter("margins");

        String ltv = request.getParameter("ltv");
        String payPeriod = request.getParameter("payperiod");
        String rate = request.getParameter("rate");

        List<BankOffers> bankList = bankOffersFacade.findAll();
        for (BankOffers offers : bankList) {
            if (offers.getBankname().equalsIgnoreCase(bankName)
                    && offers.getSalarial().equalsIgnoreCase(salarial)
                    && offers.getMargin().equalsIgnoreCase(margin)) {
                bankOffers = offers;
                isBankOfferExited = true;
                break;
            }
        }

        if (!isBankOfferExited) {
            bankOffersFacade.create(bankOffers);
        } else {
            bankOffers.setBankname(bankName);
            bankOffers.setSalarial(salarial);
            bankOffers.setMargin(margin);
        }
        loanPlan.setIdBANKOFFERS(bankOffers);

        List<LoanPlan> loanList = loanPlanFacade.findAll();
        for (LoanPlan loan : loanList) {
            if (loan.getIdBANKOFFERS().equals(bankOffers)
                    && loan.getLtv().equalsIgnoreCase(ltv)
                    && loan.getPercent().equalsIgnoreCase(rate)
                    && loan.getPayDuring().equalsIgnoreCase(payPeriod)) {
                loanPlan = loan;
                isExited = true;
                break;
            }

        }

        if (!isExited) {
            loanPlanFacade.create(loanPlan);
        }
        return loanPlan;
    }

    public Deals changeDealStatus(String dealReference, String status,String propStatus) {
       //Deals deals = dealsFacade.find(java.sql.Date.valueOf(dealReference));
        Deals deals=dealsFacade.findByDealReference(dealReference);
        changePropertyStatus(deals.getIdREALPROPERTIES().getPropertyName(), propStatus);
        deals.setStatus(status);
        dealsFacade.edit(deals);
      return deals;
    }

    public void loadPropertiesForm(HttpServletRequest request) {
        request.setAttribute("cities", citiesFacade.findAll());
        request.setAttribute("propTypes", propertyTypesFacade.findAll());
        request.setAttribute("statuco", propertyStatusFacade.findAll());
        request.setAttribute("dealType", dealTypesFacade.findAll());
        request.setAttribute("bhkRooms", numberOfRoomsFacade.findAll());
        request.setAttribute("bankOffer", bankOffersFacade.findAll());
        request.setAttribute("loanplans", loanPlanFacade.findAll());

    }

    private Amenties findDefaultAmenties() {
        return amentiesFacade.find(1);
    }

    public void changePropertyStatus(String realprperties, String posted) {
        Realproperties realpropperties = realpropertiesFacade.findByPropertyName(realprperties);
        realpropperties.setStatus(posted);
        realpropertiesFacade.edit(realpropperties);
    }

    

}
